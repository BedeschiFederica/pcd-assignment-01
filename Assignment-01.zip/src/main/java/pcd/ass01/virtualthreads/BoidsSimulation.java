package pcd.ass01.virtualthreads;

/**
 * @author Bedeschi Federica   federica.bedeschi4@studio.unibo.it
 * @author Pracucci Filippo    filippo.pracucci@studio.unibo.it
 */
public class BoidsSimulation {

    public static void main(String[] args) {
		new VirtualThreadsSimulationController();
    }
}
